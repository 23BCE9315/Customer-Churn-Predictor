import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib
import os

def load_data():
    file_path = "data/WA_Fn-UseC_-Telco-Customer-Churn.csv"
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"❌ Dataset not found at: {file_path}")
    
    df = pd.read_csv(file_path)
    df.drop("customerID", axis=1, inplace=True)
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df.dropna(inplace=True)
    return df

def preprocess_data(df):
    df = df.copy()
    le = LabelEncoder()
    for col in df.select_dtypes(include='object').columns:
        if col == "Churn":
            df[col] = df[col].map({"Yes": 1, "No": 0})
        else:
            df[col] = le.fit_transform(df[col])
    X = df.drop("Churn", axis=1)
    y = df["Churn"]
    return X, y

def train_model():
    print("📊 Loading data...")
    df = load_data()
    
    print("🧹 Preprocessing data...")
    X, y = preprocess_data(df)
    
    print("🧠 Training model...")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    joblib.dump(model, "model.pkl")
    print("✅ Model trained and saved as model.pkl")
    return model

if __name__ == "__main__":
    train_model()
